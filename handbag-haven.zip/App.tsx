
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Product, Cart, SortOption, CartItem, Order } from './types';
import { PRODUCTS, CATEGORIES, SORT_OPTIONS } from './constants';
import Header from './components/Header';
import Controls from './components/Controls';
import ProductGrid from './components/ProductGrid';
import ProductModal from './components/ProductModal';
import CartSidebar from './components/CartSidebar';
import ProductFormModal from './components/ProductFormModal';
import CheckoutModal from './components/CheckoutModal';
import LoginModal from './components/LoginModal';
import OrdersModal from './components/OrdersModal';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const savedProducts = localStorage.getItem('handbag_products');
      return savedProducts ? JSON.parse(savedProducts) : PRODUCTS;
    } catch (e) {
      return PRODUCTS;
    }
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [sort, setSort] = useState<SortOption>('featured');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<Cart>(() => {
    try {
      const savedCart = localStorage.getItem('handbag_cart');
      return savedCart ? JSON.parse(savedCart) : {};
    } catch (e) {
      return {};
    }
  });

  // Admin & Auth State
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('handbag_auth') === 'true';
  });
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Checkout & Orders State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrdersModalOpen, setIsOrdersModalOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const savedOrders = localStorage.getItem('handbag_orders');
      return savedOrders ? JSON.parse(savedOrders) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('handbag_auth', String(isAuthenticated));
  }, [isAuthenticated]);

  const updateProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
    localStorage.setItem('handbag_products', JSON.stringify(newProducts));
  };

  const updateCart = (newCart: Cart) => {
    setCart(newCart);
    localStorage.setItem('handbag_cart', JSON.stringify(newCart));
  };
  
  const updateOrders = (newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('handbag_orders', JSON.stringify(newOrders));
  }

  const filteredAndSortedProducts = useMemo(() => {
    let result = products
      .filter(p => category === 'all' || p.category === category)
      .filter(p =>
        p.title.toLowerCase().includes(searchQuery.toLowerCase())
      );

    switch (sort) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'featured':
      default:
        break;
    }
    return result;
  }, [products, searchQuery, category, sort]);

  const handleAddToCart = useCallback((product: Product, quantity: number) => {
    const newCart = { ...cart };
    if (newCart[product.id]) {
      newCart[product.id].quantity += quantity;
    } else {
      newCart[product.id] = { ...product, quantity };
    }
    updateCart(newCart);
    setSelectedProduct(null);
    setIsCartOpen(true);
  }, [cart]);

  const handleUpdateQuantity = useCallback((productId: string, newQuantity: number) => {
    const newCart = { ...cart };
    if (newQuantity > 0) {
      if (newCart[productId]) {
        newCart[productId].quantity = newQuantity;
      }
    } else {
      delete newCart[productId];
    }
    updateCart(newCart);
  }, [cart]);
  
  const handleRemoveItem = useCallback((productId: string) => {
    const newCart = { ...cart };
    delete newCart[productId];
    updateCart(newCart);
  }, [cart]);

  const handleOpenProductForm = (product: Product | null) => {
    setEditingProduct(product);
    setIsProductFormOpen(true);
  };
  
  const handleCloseProductForm = () => {
    setEditingProduct(null);
    setIsProductFormOpen(false);
  };

  const handleSaveProduct = (productData: Omit<Product, 'id'>) => {
    if (editingProduct) {
      const newProducts = products.map(p => 
        p.id === editingProduct.id ? { ...p, ...productData } : p
      );
      updateProducts(newProducts);
    } else {
      const newProduct: Product = {
        id: `h${Date.now()}`,
        ...productData,
      };
      updateProducts([...products, newProduct]);
    }
    handleCloseProductForm();
  };

  const handleDeleteProduct = (productId: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      const newProducts = products.filter(p => p.id !== productId);
      updateProducts(newProducts);
    }
  };
  
  const handleExportProducts = () => {
    const dataStr = JSON.stringify(products, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'products.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const cartCount = useMemo(() => {
    return Object.values(cart).reduce((sum, item: CartItem) => sum + item.quantity, 0);
  }, [cart]);

  const cartItems = useMemo(() => Object.values(cart), [cart]);

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handlePlaceOrder = (customerDetails: { email: string; whatsapp: string }) => {
    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      customerDetails,
      cartItems,
      total: cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0),
      createdAt: new Date().toISOString(),
      status: 'Pending',
    };

    updateOrders([...orders, newOrder]);
    
    alert('Thank you for your order! We will contact you shortly via email or WhatsApp to confirm the details.');
    
    updateCart({});
    setIsCheckoutOpen(false);
  };

  const handleLogin = (success: boolean) => {
    if (success) {
      setIsAuthenticated(true);
      setIsLoginOpen(false);
    } else {
      alert('Invalid username or password.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleAdminClick = () => {
    if (isAuthenticated) {
      handleLogout();
    } else {
      setIsLoginOpen(true);
    }
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    const newOrders = orders.map(o => o.id === orderId ? { ...o, status } : o);
    updateOrders(newOrders);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        onSearchChange={setSearchQuery}
        cartCount={cartCount}
        onCartClick={() => setIsCartOpen(true)}
        isAuthenticated={isAuthenticated}
        onAdminClick={handleAdminClick}
      />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <Controls
          categories={CATEGORIES}
          sortOptions={SORT_OPTIONS}
          onCategoryChange={setCategory}
          onSortChange={(val) => setSort(val as SortOption)}
          isAuthenticated={isAuthenticated}
          onAddProductClick={() => handleOpenProductForm(null)}
          onExportClick={handleExportProducts}
          onViewOrdersClick={() => setIsOrdersModalOpen(true)}
        />
        <ProductGrid
          products={filteredAndSortedProducts}
          onProductClick={setSelectedProduct}
          isAuthenticated={isAuthenticated}
          onEditProduct={handleOpenProductForm}
          onDeleteProduct={handleDeleteProduct}
        />
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        Handbag Haven &copy; {new Date().getFullYear()}
      </footer>

      {isLoginOpen && <LoginModal onClose={() => setIsLoginOpen(false)} onLogin={handleLogin} />}

      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}
      
      {isAuthenticated && isProductFormOpen && (
        <ProductFormModal
          product={editingProduct}
          onClose={handleCloseProductForm}
          onSave={handleSaveProduct}
          categories={CATEGORIES.filter(c => c !== 'all')}
        />
      )}

      {isCheckoutOpen && (
        <CheckoutModal 
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          onPlaceOrder={handlePlaceOrder}
          cartItems={cartItems}
        />
      )}

      {isAuthenticated && isOrdersModalOpen && (
        <OrdersModal
            isOpen={isOrdersModalOpen}
            onClose={() => setIsOrdersModalOpen(false)}
            orders={orders}
            onUpdateStatus={handleUpdateOrderStatus}
        />
      )}

      <CartSidebar
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckoutClick={handleCheckout}
      />
    </div>
  );
};

export default App;