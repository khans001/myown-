
import React from 'react';
import { CartItem } from '../types';

interface CartItemProps {
  item: CartItem;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
}

const CartItemComponent: React.FC<CartItemProps> = ({ item, onUpdateQuantity, onRemoveItem }) => {
  return (
    <div className="flex items-center gap-4">
      <img src={item.image} alt={item.title} className="w-20 h-20 object-cover rounded-md" />
      <div className="flex-grow">
        <h4 className="font-semibold text-sm">{item.title}</h4>
        <p className="text-gray-500 text-xs">${item.price.toFixed(2)}</p>
        <div className="flex items-center mt-2">
          <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="w-6 h-6 border rounded-l">-</button>
          <input 
            type="text" 
            value={item.quantity}
            readOnly
            className="w-8 h-6 text-center border-t border-b" 
          />
          <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="w-6 h-6 border rounded-r">+</button>
        </div>
      </div>
      <div className="text-right">
        <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
        <button onClick={() => onRemoveItem(item.id)} className="text-red-500 hover:text-red-700 text-xs mt-1">Remove</button>
      </div>
    </div>
  );
};

export default CartItemComponent;