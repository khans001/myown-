
import React from 'react';

interface HeaderProps {
  onSearchChange: (query: string) => void;
  cartCount: number;
  onCartClick: () => void;
  isAuthenticated: boolean;
  onAdminClick: () => void;
}

const ShoppingBagIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
    </svg>
);


const Header: React.FC<HeaderProps> = ({ onSearchChange, cartCount, onCartClick, isAuthenticated, onAdminClick }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-40">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold text-accent">Handbag Haven</h1>
          </div>
          <div className="hidden md:block">
            <div className="relative">
              <input
                type="search"
                placeholder="Search handbags..."
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-64 lg:w-96 pl-4 pr-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-accent-dark focus:border-transparent transition"
              />
            </div>
          </div>
          <div className="ml-4 flex items-center gap-4">
            <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-600">Admin</span>
                <button
                    type="button"
                    className={`relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark ${isAuthenticated ? 'bg-accent' : 'bg-gray-200'}`}
                    role="switch"
                    aria-checked={isAuthenticated}
                    onClick={onAdminClick}
                >
                    <span
                    aria-hidden="true"
                    className={`inline-block w-5 h-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200 ${isAuthenticated ? 'translate-x-5' : 'translate-x-0'}`}
                    />
                </button>
            </div>
            <button
              onClick={onCartClick}
              className="relative p-2 rounded-full text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark"
            >
              <ShoppingBagIcon className="h-6 w-6" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-accent rounded-full">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;