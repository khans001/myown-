
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onProductClick: (product: Product) => void;
  isAuthenticated: boolean;
  onEdit: (product: Product) => void;
  onDelete: (productId: string) => void;
}

const EditIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" />
    </svg>
);

const DeleteIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);

const ProductCard: React.FC<ProductCardProps> = ({ product, onProductClick, isAuthenticated, onEdit, onDelete }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden group transform hover:-translate-y-1 transition-transform duration-300 flex flex-col relative">
        {isAuthenticated && (
            <div className="absolute top-2 right-2 z-10 flex flex-col gap-2">
                <button 
                    onClick={(e) => { e.stopPropagation(); onEdit(product); }} 
                    className="p-2 bg-white/80 rounded-full shadow-md hover:bg-white text-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    aria-label={`Edit ${product.title}`}
                >
                    <EditIcon className="h-5 w-5" />
                </button>
                <button 
                    onClick={(e) => { e.stopPropagation(); onDelete(product.id); }} 
                    className="p-2 bg-white/80 rounded-full shadow-md hover:bg-white text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
                    aria-label={`Delete ${product.title}`}
                >
                    <DeleteIcon className="h-5 w-5" />
                </button>
            </div>
        )}
      <div className="relative">
        <img src={product.image} alt={product.title} className="w-full h-56 object-cover" />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-gray-800 truncate">{product.title}</h3>
        <div className="mt-2 text-xl font-bold text-accent">${product.price.toFixed(2)}</div>
        <div className="mt-auto pt-4">
            <button
            onClick={() => onProductClick(product)}
            className="w-full bg-gray-800 text-white py-2 px-4 rounded-md hover:bg-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark transition-colors duration-300"
            >
            Quick View
            </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;