
import React from 'react';

interface ControlsProps {
  categories: string[];
  sortOptions: { value: string; label: string }[];
  onCategoryChange: (category: string) => void;
  onSortChange: (sort: string) => void;
  isAuthenticated: boolean;
  onAddProductClick: () => void;
  onExportClick: () => void;
  onViewOrdersClick: () => void;
}

const Controls: React.FC<ControlsProps> = ({ categories, sortOptions, onCategoryChange, onSortChange, isAuthenticated, onAddProductClick, onExportClick, onViewOrdersClick }) => {
  return (
    <section className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
      <div className="flex items-center gap-4">
        <div>
          <label htmlFor="categoryFilter" className="sr-only">Category:</label>
          <select
            id="categoryFilter"
            onChange={(e) => onCategoryChange(e.target.value)}
            className="py-2 px-4 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-accent-dark focus:border-transparent capitalize"
          >
            {categories.map(cat => (
              <option key={cat} value={cat} className="capitalize">{cat}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="sortSelect" className="sr-only">Sort by:</label>
          <select
            id="sortSelect"
            onChange={(e) => onSortChange(e.target.value)}
            className="py-2 px-4 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-accent-dark focus:border-transparent"
          >
            {sortOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        </div>
      </div>
      
      {isAuthenticated && (
        <div className="flex items-center gap-2">
          <button
            onClick={onViewOrdersClick}
            className="py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark"
          >
            View Orders
          </button>
          <button
            onClick={onAddProductClick}
            className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-accent hover:bg-accent-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark"
          >
            Add Product
          </button>
          <button
            onClick={onExportClick}
            className="py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark"
          >
            Export JSON
          </button>
        </div>
      )}
    </section>
  );
};

export default Controls;