
import React from 'react';
import { Product } from '../types';
import ProductCard from './ProductCard';

interface ProductGridProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  isAuthenticated: boolean;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, onProductClick, isAuthenticated, onEditProduct, onDeleteProduct }) => {
  return (
    <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      {products.map(product => (
        <ProductCard 
            key={product.id} 
            product={product} 
            onProductClick={onProductClick}
            isAuthenticated={isAuthenticated}
            onEdit={onEditProduct}
            onDelete={onDeleteProduct}
        />
      ))}
    </section>
  );
};

export default ProductGrid;