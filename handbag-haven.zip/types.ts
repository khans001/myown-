
export interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type Cart = {
  [productId: string]: CartItem;
};

export type SortOption = 'featured' | 'price-asc' | 'price-desc';

export interface Order {
  id: string;
  customerDetails: {
    email: string;
    whatsapp: string;
  };
  cartItems: CartItem[];
  total: number;
  createdAt: string;
  status: 'Pending' | 'Shipped' | 'Completed' | 'Cancelled';
}