
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: "h1",
    title: "Classic Leather Tote",
    price: 79.00,
    category: "tote",
    image: "https://picsum.photos/seed/h1/400/400"
  },
  {
    id: "h2",
    title: "Minimal Crossbody",
    price: 49.50,
    category: "crossbody",
    image: "https://picsum.photos/seed/h2/400/400"
  },
  {
    id: "h3",
    title: "Evening Clutch",
    price: 39.99,
    category: "clutch",
    image: "https://picsum.photos/seed/h3/400/400"
  },
  {
    id: "h4",
    title: "Casual Backpack",
    price: 89.00,
    category: "backpack",
    image: "https://picsum.photos/seed/h4/400/400"
  },
  {
    id: "h5",
    title: "Woven Straw Tote",
    price: 59.00,
    category: "tote",
    image: "https://picsum.photos/seed/h5/400/400"
  },
  {
    id: "h6",
    title: "Slim Wallet Clutch",
    price: 24.99,
    category: "clutch",
    image: "https://picsum.photos/seed/h6/400/400"
  },
  {
    id: "h7",
    title: "Adventure Backpack",
    price: 120.00,
    category: "backpack",
    image: "https://picsum.photos/seed/h7/400/400"
  },
  {
    id: "h8",
    title: "Sleek Crossbody",
    price: 65.50,
    category: "crossbody",
    image: "https://picsum.photos/seed/h8/400/400"
  }
];

export const CATEGORIES = ['all', 'tote', 'clutch', 'crossbody', 'backpack'];

export const SORT_OPTIONS = [
    { value: 'featured', label: 'Featured' },
    { value: 'price-asc', label: 'Price: Low to High' },
    { value: 'price-desc', label: 'Price: High to Low' },
];